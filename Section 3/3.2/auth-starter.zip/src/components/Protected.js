import React from 'react';
function Protected(props) {
  // console.log(props);
  return <h3>Protected</h3>;
}

export default Protected;
