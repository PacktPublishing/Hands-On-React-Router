import React from 'react';

export function Public() {
  return <h3>Public</h3>;
}
