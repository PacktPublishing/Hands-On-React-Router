import React, { Component } from 'react';

class Login extends Component {
  render() {
    return <div>Login Route</div>;
  }
}

export default Login;
