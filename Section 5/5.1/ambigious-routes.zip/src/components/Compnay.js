import React from 'react';

function Compnay() {
  return <div>Company profile</div>;
}

export default Compnay;
