import React from 'react';

function Home(props) {
  return (
    <div className="jumbotron">
      <h1>Blogging Application</h1>
      <p>We are going to build a blogging application in this course</p>
    </div>
  );
}

export default Home;
