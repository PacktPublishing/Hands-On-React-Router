import React from 'react';

function About(props) {
  return <div>About us</div>;
}
export default About;
