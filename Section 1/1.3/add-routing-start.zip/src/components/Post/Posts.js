import React from 'react';

function Posts(props) {
  return <div>Posts List</div>;
}
export default Posts;
