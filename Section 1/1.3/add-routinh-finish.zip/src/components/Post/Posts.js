import React from 'react';

function Posts(props) {
  return <div>Posts List Update</div>;
}
export default Posts;
