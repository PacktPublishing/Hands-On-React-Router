import React from 'react';

function Foo() {
  return (
    <div>
      <h3>Foo</h3>
    </div>
  );
}

export default Foo;
