import React from 'react';

function Home() {
  return (
    <div>
      <h3>Home</h3>
    </div>
  );
}

export default Home;
