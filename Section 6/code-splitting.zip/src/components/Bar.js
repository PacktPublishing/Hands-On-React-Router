import React from 'react';

function Bar(props) {
  return <div>Bar</div>;
}
export default Bar;
