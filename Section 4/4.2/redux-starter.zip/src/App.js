import React from 'react';

const App = () => <div>Connect React Router with Redux</div>;
export default App;
