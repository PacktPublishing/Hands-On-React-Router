import React from 'react';

const NoMatch = () => <div>No Match</div>;

export default NoMatch;
